import java.util.Random;
public class Stack {
    int size;
    int top;
    char[] veriler;

    Stack(int sizeParametresi){
        this.size = sizeParametresi;
        this.top = -1;
        veriler = new char[size];
    }
    void push(char data)
    {
        if(DoluMu()) {
            System.out.println("Stack Dolu.");}
        else
        {
            this.top++;
            this.veriler[this.top]= data;
        }
    }
    public void yiginSiralamam() {
        String sesliHarfler = "aeıiouüö";
        String sessizHarfler = "qwrtypğsdfghjklşçmnbvcxz";
        Random random = new Random();
        char data = (char) (random.nextInt(26)+'a');
        if(BosMu() || sesliHarfler.indexOf(data) != -1 && sessizHarfler.indexOf(veriler[top]) != -1 || sessizHarfler.indexOf(data) != -1 && sesliHarfler.indexOf(veriler[top]) != -1) {
            push(data);
        }
        else {
            
            pop();
            char yeniHarf;
            if(sesliHarfler.indexOf(data) != -1) {
            
                yeniHarf = sessizHarfler.charAt(random.nextInt(sessizHarfler.length()));
            }
            else {
               
                yeniHarf = sesliHarfler.charAt(random.nextInt(sesliHarfler.length()));
            }
            if(!DoluMu()){
                push(yeniHarf);
            }  
        }
    }
    public char pop(){
    if (BosMu()){
        System.out.println("Liste Bos! ");
        return '0';
    }
    else {
        this.top = this.top-1;
        return this.veriler[this.top+1];
    }
    }
    public void print(){
    if (BosMu()){
        System.out.println("Liste Bos! ");
    }
    else {
        for (int i=this.top;i>-1;i--){
            System.out.println(this.veriler[i]);
        }
    }
    }
    public void resetleme(){
    this.top=-1;
    }
    public boolean DoluMu(){
        if (this.top == (this.size-1)){
            return true;
        }
        else {
            return false;
        }
    }
    public boolean BosMu(){
        if (this.top == -1){
            return true;
        }
        else {
            return false;
        }
    }
}
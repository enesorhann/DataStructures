public class Node {
    int data;
    Node next;
    Node prev;
    public Node(int dataParametre){
        this.next = null;
        this.prev = null;
        this.data=dataParametre;
    }
}

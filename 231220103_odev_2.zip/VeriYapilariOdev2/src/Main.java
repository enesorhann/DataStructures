public class Main {
    public static void main(String[] args) {
        Stack stack = new Stack(6);
      
        for(int i = 0;i<stack.size;i++){
           stack.yiginSiralamam();
        }
        stack.print();
    }}
import java.io.*;
import java.util.Scanner;

public class Main {
    /**
     * @param args
     */
    public static void main(String[] args) throws IOException {
        System.out.println("----Liste Yapisi Odev Uygulamasi----");
        String liste = "C:\\java\\VeriYapilariOdevi\\veriyapilari.txt";
        LinkedList list = new LinkedList();

        list = list.readFromFile(liste);
        boolean sonVer = true;
        while(sonVer){
        System.out.println("Yapmak İstediginiz Islem:\r\n" + //
                "1. Listeleme\r\n" + //
                "2. Ekleme\r\n" + //
                "3. Arama\r\n" + //
                "4. Silme\r\n" + //
                "5. Tasima\r\n" + //
                "6. Cikis");



        Scanner scanner = new Scanner(System.in);
        int secim = scanner.nextInt();
        switch(secim){

            case 1:

         System.out.println("Liste: ");
                list.print(liste);
                System.out.println();
                break;

            case 2:

                System.out.println("Isim,Soyisim,Numara Bilgilerini Giriniz: ");
                String isim =scanner.next();
                String Soyisim =scanner.next();
                int numara = scanner.nextInt();
                list =list.insert(list,isim,Soyisim,numara);
                list.print(liste);
                System.out.println();
                break;

            case 3:

                System.out.println("Aratmak istediginiz Soyismini Giriniz: ");
                Scanner scanner2 = new Scanner(System.in);
                String aranan = scanner2.next();
                list.searchList(aranan);
                break;

            case 4:

                System.out.println("Silmek istediginiz Kisiye Ait Numarayi Giriniz: ");
                Scanner scanner3 = new Scanner(System.in);
                int silinecek = scanner3.nextInt();
                list.delete(silinecek);
                System.out.println();
                list.print(liste);
                System.out.println();
                break;

            case 5:

                System.out.println("Tasimak istediginiz numaranin gösterdigi kayit,listenin n. sirasina tasinacaktir.(numara,n)");
                Scanner scanner4 = new Scanner(System.in);
                int tasinacak_numara = scanner4.nextInt();
                int hedef_konum = scanner4.nextInt();

                list.Tasima(tasinacak_numara,hedef_konum);
                System.out.println();
                list.print(liste);
                System.out.println();
                break;

            case 6:

                System.out.println("Cikis");
                sonVer = false;
                try {
                    list.writeToFile(liste);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                System.exit(0);
                break;
        }}}}
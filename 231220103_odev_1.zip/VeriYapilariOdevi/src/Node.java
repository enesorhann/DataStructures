
public class Node {

    String isim;
    String soyisim;
    int numara;
    Node next;

    public  Node(String isim,String soyisim,int numara){
        this.isim = isim;
        this.soyisim = soyisim;
        this.numara = numara;
        this.next = null;
    }
}

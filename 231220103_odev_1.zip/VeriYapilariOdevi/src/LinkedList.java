import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class LinkedList {

    Node root;

    public void writeToFile(String dosyaAdi) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(dosyaAdi));
        Node iter = root;
        while (iter != null) {
            writer.write(iter.isim + "#" + iter.soyisim + "#" + iter.numara + "\n");
            iter = iter.next;
        }
        writer.close();
    }

    public LinkedList readFromFile(String liste) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(liste.toString()));
        LinkedList listem = new LinkedList();
        String line;
        while ((line = reader.readLine()) != null) {
            String[] veri = line.split("#");
            if (veri.length == 3) {
                String isim = veri[0];
                String soyisim = veri[1];
                int numara = Integer.parseInt(veri[2]);
                listem.insert(listem,isim, soyisim, numara);
            }
        }
        reader.close();
        return listem;
    }
    //  ayni numaraya sahip kayit listeye eklenmemelidir.
    public LinkedList insert(LinkedList liste,String isim,String soyisim,int numara){
        Node yenidugum = new Node(isim,soyisim,numara);
        if (root==null){
            root=yenidugum;
        }
        else {
            Node iter = root;
            boolean varMi = false;

            while(iter!=null){
                if(iter.numara == numara){
                    varMi = true;
                    System.out.println("Aynı Numarada Kayit Eklenemez;( ");
                    System.out.println();
                    break;
                }
                if (iter.next==null){
                    break;
                }
                iter = iter.next;
            }
            if(!varMi){
                if (iter.numara!=numara){
                iter.next = yenidugum;
            }
        }
    }
        return liste;
    }
    public void Tasima(int tasinanKisininNumarasi,int hedef_konum){

        Node iter = root;
        Node tasinanNumara_prev=null;
        Node tasinanNumara=null;
        Node hedef=null;
        Node hedef_prev=null;
        int sayac = 1;
        int liste_boyutu = 0;

        if(root==null){
            System.out.println("Liste Bos:( ");
        }

        while(iter!=null){  // Bu Dongu liste boyutumuzu belirliyor.
            liste_boyutu++;
            iter=iter.next;
        }
        if(hedef_konum<1 || hedef_konum>liste_boyutu){
            System.out.println("Liste boyutu disinda bir deger girdiniz! ");
            return;
        }

        iter = root;

        while (iter != null) {

        if (iter.numara == tasinanKisininNumarasi) {
            tasinanNumara = iter;
            break;
        }
        tasinanNumara_prev = iter;
        iter = iter.next;
        sayac++;
        }
        if (tasinanNumara == null) {
            System.out.println("Tasinacak Dugum Bulunamadi! ");
        }
        iter = root;
        sayac = 1;

        // Hedef konumu bul
        while (iter != null) {
            if (sayac == hedef_konum) {
                hedef = iter;
                break;
            }
            hedef_prev = iter;
            iter = iter.next;
            sayac++;
        }


        if (tasinanNumara_prev == null) {
            root = tasinanNumara.next;
        } else {
            tasinanNumara_prev.next = tasinanNumara.next;
        }


        if (hedef_prev == null) {
            tasinanNumara.next = root;
            root = tasinanNumara;
        } else {
            tasinanNumara.next = hedef;
            hedef_prev.next = tasinanNumara;
        }
    }
    //Listede aranan soyad yoksa
    //“Aranilan kayit bulunamadi” mesaji verilecektir.
    public void searchList(String soyisim) {

        boolean kontrol = false;
        Node iter = root;

    while (iter != null) {


            if (iter.soyisim.equals(soyisim)) {
                System.out.println(iter.isim + " " + iter.soyisim + " " + iter.numara);
                kontrol = true;

                System.out.print("Istenen kayit bulundu mu? (e/h): ");
                Scanner scanner4 = new Scanner(System.in);
                    String cevap = scanner4.next();
                    if (cevap.equalsIgnoreCase("e")) {
                        return;
                    }
                }
            iter = iter.next;
            }
        if (kontrol) {
            System.out.println("Aranan soyisimde bir kayit bulunamadi.");
            System.out.println();
        }
}
public void print(String liste){
        Node iter = root;
        while (iter!=null){
            System.out.println("Isim: "+iter.isim+" Soyisim: "+iter.soyisim+" Numara: "+iter.numara);
            iter = iter.next;
        }
    }
    // Girilen numaraya ait kayit yoksa
//“Aranilan kayit bulunamadi” mesaji verilecektir (Ayni numaraya sahip kayit bulunmamalidir).
    public void delete(int silinecekNumara){

        if (root!=null && root.numara==silinecekNumara){
            root = root.next;

        }
        else {
            Node iter = root;
            while (iter.next!=null && iter.next.numara!=silinecekNumara){
                iter=iter.next;
            }
            if (iter.next==null){
                System.out.println("Veri Bulunamadi! ");
            }
            else {
                iter.next = iter.next.next;
            }
        }
    }


    }